"""Build the BM25 retrieval index over the document directory.

Usage:
    python src/build_index.py [--config config.yaml]
"""

import argparse
import os
import sys

import joblib

sys.path.append(os.path.dirname(__file__))
from utils import load_config
from retriever import Retriever


def main():
    parser = argparse.ArgumentParser(description="Build the RAG retrieval index.")
    parser.add_argument("--config", default="config.yaml", help="Path to config.yaml")
    args = parser.parse_args()

    config = load_config(args.config)

    print(f"Chunking and indexing documents in {config['documents_dir']} ...")
    retriever = Retriever.build(
        config["documents_dir"],
        config["chunk_size_words"],
        config["chunk_overlap_words"],
        config.get("bm25_k1", 1.5),
        config.get("bm25_b", 0.75),
    )
    print(f"Indexed {len(retriever.chunks)} chunks from "
          f"{len(set(c['source'] for c in retriever.chunks))} documents.")

    os.makedirs(os.path.dirname(config["index_path"]), exist_ok=True)
    joblib.dump(retriever, config["index_path"])
    print(f"Index saved to {config['index_path']}")


if __name__ == "__main__":
    main()
